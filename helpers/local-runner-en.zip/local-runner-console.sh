java -Xms512m -Xmx1G -server -jar "local-runner.jar" local-runner-console.properties local-runner-console.default.properties
