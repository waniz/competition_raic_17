package model;

public enum WeatherType {
    CLEAR,
    CLOUD,
    RAIN
}
