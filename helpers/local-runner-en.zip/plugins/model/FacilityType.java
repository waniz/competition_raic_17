package model;

public enum FacilityType {
    CONTROL_CENTER,
    VEHICLE_FACTORY
}
