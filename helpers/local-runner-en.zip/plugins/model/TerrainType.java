package model;

public enum TerrainType {
    PLAIN,
    SWAMP,
    FOREST
}
