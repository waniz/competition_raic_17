java -Xms512m -Xmx1G -server -jar "local-runner.jar" local-runner-sync.properties local-runner-sync.default.properties &
