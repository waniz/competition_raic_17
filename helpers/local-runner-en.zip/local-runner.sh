java -Xms512m -Xmx2G -server -jar "local-runner.jar" local-runner.properties local-runner.default.properties &
